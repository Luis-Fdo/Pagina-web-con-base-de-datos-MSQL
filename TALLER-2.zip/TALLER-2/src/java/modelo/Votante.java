/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author luisf
 */
public class Votante implements Serializable {

    private String nombre;
    private String apellido;
    private String fechaNacimiento;
    private String tipoEleccion;
    private String fechaEleccion;
// Constructor
    public Votante(String nombre, String apellido, String fechaNacimiento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.tipoEleccion = "";  // Se asignará después en EleccionServlet
        this.fechaEleccion = "";
    }

    public Votante() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    // Getters y Setters
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getFechaNacimiento() { return fechaNacimiento; }

    public String getTipoEleccion() { return tipoEleccion; }
    public void setTipoEleccion(String tipoEleccion) { this.tipoEleccion = tipoEleccion; }

    public String getFechaEleccion() { return fechaEleccion; }
    public void setFechaEleccion(String fechaEleccion) { this.fechaEleccion = fechaEleccion; }
    
}
