/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author luisf
 */
public class Candidato implements Serializable {
    private String nombre;
    private String cargo;
    private String foto; // Ruta donde se almacena la imagen
    private String partido;
    
    public Candidato(String nombre, String cargo, String foto, String partido) {
        this.nombre = nombre;
        this.cargo = cargo;
        this.foto = foto;
        this.partido = partido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public String getFoto() {
        return foto;
    }

    public String getPartido() {
        return partido;
    }
    
}
