/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import modelo.Candidato;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.nio.file.Paths;

/**
 *
 * @author luisf
 */
@WebServlet(urlPatterns = {"/RegistroCandidatoServlet"})
public class RegistroCandidatoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegistroCandidatoServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegistroCandidatoServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nombre = request.getParameter("nombre");
        String cargo = request.getParameter("cargo");
        String partido = request.getParameter("partido");
        String foto = request.getParameter("foto");

        // Depuración en consola
        System.out.println("Nombre recibido: " + nombre);
        System.out.println("Cargo recibido: " + cargo);
        System.out.println("Partido recibido: " + partido);

        // Validación de campos vacíos
        if (nombre == null || nombre.trim().isEmpty() ||
            cargo == null || cargo.trim().isEmpty() ||
            partido == null || partido.trim().isEmpty()) {
            response.getWriter().println("Error: Todos los campos son obligatorios.");
            return;
        }

        // Crear candidato sin imagen
        Candidato candidato = new Candidato(nombre, cargo, " ", partido);

        // Obtener o crear la lista en el contexto de la aplicación
        List<Candidato> candidatos = (List<Candidato>) getServletContext().getAttribute("candidatos");
        if (candidatos == null) {
            candidatos = new ArrayList<>();
            getServletContext().setAttribute("candidatos", candidatos);
        }

        // Agregar candidato a la lista
        candidatos.add(candidato);
        System.out.println("Candidato agregado: " + candidato.getNombre());

        // Redirigir a la lista de candidatos
        response.sendRedirect("mostrarCandidatos.jsp");
    
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
